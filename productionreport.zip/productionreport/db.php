<?php
	$database_username = 'root';
	$database_password = 'spiproject';
	$pdo_conn = new PDO( 'mysql:host=localhost;dbname=embase', $database_username, $database_password );
?>